// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2020.2 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xmodel.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XModel_CfgInitialize(XModel *InstancePtr, XModel_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->Ccontrol_BaseAddress = ConfigPtr->Ccontrol_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XModel_Set_price(XModel *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XModel_WriteReg(InstancePtr->Control_BaseAddress, XMODEL_CONTROL_ADDR_PRICE_DATA, (u32)(Data));
    XModel_WriteReg(InstancePtr->Control_BaseAddress, XMODEL_CONTROL_ADDR_PRICE_DATA + 4, (u32)(Data >> 32));
}

u64 XModel_Get_price(XModel *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XModel_ReadReg(InstancePtr->Control_BaseAddress, XMODEL_CONTROL_ADDR_PRICE_DATA);
    Data += (u64)XModel_ReadReg(InstancePtr->Control_BaseAddress, XMODEL_CONTROL_ADDR_PRICE_DATA + 4) << 32;
    return Data;
}

void XModel_Set_prediction(XModel *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XModel_WriteReg(InstancePtr->Ccontrol_BaseAddress, XMODEL_CCONTROL_ADDR_PREDICTION_DATA, (u32)(Data));
    XModel_WriteReg(InstancePtr->Ccontrol_BaseAddress, XMODEL_CCONTROL_ADDR_PREDICTION_DATA + 4, (u32)(Data >> 32));
}

u64 XModel_Get_prediction(XModel *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XModel_ReadReg(InstancePtr->Ccontrol_BaseAddress, XMODEL_CCONTROL_ADDR_PREDICTION_DATA);
    Data += (u64)XModel_ReadReg(InstancePtr->Ccontrol_BaseAddress, XMODEL_CCONTROL_ADDR_PREDICTION_DATA + 4) << 32;
    return Data;
}

