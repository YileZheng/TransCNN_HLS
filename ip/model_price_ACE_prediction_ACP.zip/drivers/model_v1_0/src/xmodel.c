// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.1 (64-bit)
// Tool Version Limit: 2022.04
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xmodel.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XModel_CfgInitialize(XModel *InstancePtr, XModel_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XModel_Start(XModel *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XModel_ReadReg(InstancePtr->Control_BaseAddress, XMODEL_CONTROL_ADDR_AP_CTRL) & 0x80;
    XModel_WriteReg(InstancePtr->Control_BaseAddress, XMODEL_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XModel_IsDone(XModel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XModel_ReadReg(InstancePtr->Control_BaseAddress, XMODEL_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XModel_IsIdle(XModel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XModel_ReadReg(InstancePtr->Control_BaseAddress, XMODEL_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XModel_IsReady(XModel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XModel_ReadReg(InstancePtr->Control_BaseAddress, XMODEL_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XModel_EnableAutoRestart(XModel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XModel_WriteReg(InstancePtr->Control_BaseAddress, XMODEL_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XModel_DisableAutoRestart(XModel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XModel_WriteReg(InstancePtr->Control_BaseAddress, XMODEL_CONTROL_ADDR_AP_CTRL, 0);
}

void XModel_Set_price(XModel *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XModel_WriteReg(InstancePtr->Control_BaseAddress, XMODEL_CONTROL_ADDR_PRICE_DATA, (u32)(Data));
    XModel_WriteReg(InstancePtr->Control_BaseAddress, XMODEL_CONTROL_ADDR_PRICE_DATA + 4, (u32)(Data >> 32));
}

u64 XModel_Get_price(XModel *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XModel_ReadReg(InstancePtr->Control_BaseAddress, XMODEL_CONTROL_ADDR_PRICE_DATA);
    Data += (u64)XModel_ReadReg(InstancePtr->Control_BaseAddress, XMODEL_CONTROL_ADDR_PRICE_DATA + 4) << 32;
    return Data;
}

void XModel_Set_prediction(XModel *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XModel_WriteReg(InstancePtr->Control_BaseAddress, XMODEL_CONTROL_ADDR_PREDICTION_DATA, (u32)(Data));
    XModel_WriteReg(InstancePtr->Control_BaseAddress, XMODEL_CONTROL_ADDR_PREDICTION_DATA + 4, (u32)(Data >> 32));
}

u64 XModel_Get_prediction(XModel *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XModel_ReadReg(InstancePtr->Control_BaseAddress, XMODEL_CONTROL_ADDR_PREDICTION_DATA);
    Data += (u64)XModel_ReadReg(InstancePtr->Control_BaseAddress, XMODEL_CONTROL_ADDR_PREDICTION_DATA + 4) << 32;
    return Data;
}

void XModel_InterruptGlobalEnable(XModel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XModel_WriteReg(InstancePtr->Control_BaseAddress, XMODEL_CONTROL_ADDR_GIE, 1);
}

void XModel_InterruptGlobalDisable(XModel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XModel_WriteReg(InstancePtr->Control_BaseAddress, XMODEL_CONTROL_ADDR_GIE, 0);
}

void XModel_InterruptEnable(XModel *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XModel_ReadReg(InstancePtr->Control_BaseAddress, XMODEL_CONTROL_ADDR_IER);
    XModel_WriteReg(InstancePtr->Control_BaseAddress, XMODEL_CONTROL_ADDR_IER, Register | Mask);
}

void XModel_InterruptDisable(XModel *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XModel_ReadReg(InstancePtr->Control_BaseAddress, XMODEL_CONTROL_ADDR_IER);
    XModel_WriteReg(InstancePtr->Control_BaseAddress, XMODEL_CONTROL_ADDR_IER, Register & (~Mask));
}

void XModel_InterruptClear(XModel *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    //XModel_WriteReg(InstancePtr->Control_BaseAddress, XMODEL_CONTROL_ADDR_ISR, Mask);
}

u32 XModel_InterruptGetEnabled(XModel *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XModel_ReadReg(InstancePtr->Control_BaseAddress, XMODEL_CONTROL_ADDR_IER);
}

u32 XModel_InterruptGetStatus(XModel *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    // Current Interrupt Clear Behavior is Clear on Read(COR).
    return XModel_ReadReg(InstancePtr->Control_BaseAddress, XMODEL_CONTROL_ADDR_ISR);
}

